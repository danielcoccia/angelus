<script src="{{ URL::asset('/js/vendors.bundle.js') }}"></script>
<script src="{{ URL::asset('/js/app.bundle.js') }}"></script>
<script src="{{ URL::asset('/js/sidebarActive.js') }}"></script>