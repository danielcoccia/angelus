<link rel="stylesheet" media="screen, print" href="{{ URL::asset('/css/vendors.bundle.css') }}">
<link rel="stylesheet" media="screen, print" href="{{ URL::asset('/css/app.bundle.css') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{ URL::asset('/img/favicon/apple-touch-icon.png') }}">
<link rel="icon" type="image/png" sizes="32x32" href="{{ URL::asset('/img/favicon/favicon-32x32.png') }}">
<link rel="mask-icon" href="{{ URL::asset('/img/favicon/safari-pinned-tab.svg') }}" color="#5bbad5">