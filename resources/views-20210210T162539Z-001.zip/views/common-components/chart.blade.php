  <div class="col-sm-6">
                            <div class="state-information d-none d-sm-block">
                                <div class="state-graph">
                                    <div id="{{ $chart1_id }}"></div>
                                    <div class="info">{{ $chart1_title }}</div>
                                </div>
                                <div class="state-graph">
                                    <div id="{{ $chart2_id }}"></div>
                                    <div class="info">{{ $chart3_title }}</div>
                                </div>
                            </div>
                        </div>