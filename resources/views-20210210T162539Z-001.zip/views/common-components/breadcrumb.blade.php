<div class="col-sm-6">
                            <div class="page-title-box">
                                <h4>{{$title}}</h4>
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">{{$li1}}</a></li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">{{$li2}}</a></li>
                                        <li class="breadcrumb-item active">{{$li3}}</li>
                                    </ol>
                            </div>
                        </div>